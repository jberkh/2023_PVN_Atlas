#' String concatenation
#'
#' Concatenate strings with the + operator
#'
#' @param x String object or string vector
#' @param y String object string vector. Coerced to string if other type
#' @return A concatenated string (vector)
#' @export
#' @examples
#' "Hello " + "World"
#' "Hello " + c("World", "Moon")
#' "Label_" + 1:5

"+" = function(x,y) {
  if (is.character(x) || is.character(y)) {
    return(paste0(x , y))
  } else {
    .Primitive("+")(x,y)
  }
}