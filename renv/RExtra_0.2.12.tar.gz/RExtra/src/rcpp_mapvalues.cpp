#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
CharacterVector rcpp_mapvalues(CharacterVector x, CharacterVector from, CharacterVector to) {
	CharacterVector xx = clone(x);
	for (int i = 0; i < xx.length(); i++) {
		for (int j = 0; j < from.length(); j++) {
			if (xx[i] == from[j]) {
				xx[i] = to[j];
			  break;
			}
		}
	}
	return(xx);
}
