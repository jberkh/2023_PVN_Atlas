#include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]
CharacterVector rcpp_pass_two(CharacterVector p1, CharacterVector from, CharacterVector to, CharacterVector allsymb) {
    CharacterVector p2 = clone(p1);
    // Cloned p1 to p2
    for (int i = 0; i < p2.length(); i++) {
        // Loop over p2
        if (std::find(allsymb.begin(), allsymb.end(), p2[i]) == allsymb.end()) {
            // Only continue w/ p2 values not in allsymb
            // Now, check how many conversion for p1[i] possible
            int n = 0;
            for (int j = 0; j < from.length(); j++) {
            // Now, check how many conversions for p1[i] are possible
            // Only count conversions for which the 'to' value not in p1
                if (p2[i] == from[j] && std::find(p1.begin(), p1.end(), to[j]) == p1.end()) {
                    n = ++n;
                }
            }
            if (n == 1) {
                // If only one conversion possible, do that
                for (int j = 0; j < from.length(); j++) {
                    if (p2[i] == from[j] && std::find(p1.begin(), p1.end(), to[j]) == p1.end()) {
                        p2[i] = to[j];
                    }
                }
            }
        }
    }
    return(p2);
}

