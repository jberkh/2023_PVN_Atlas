#include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::export]]
NumericMatrix rcpp_merge_by_row(NumericMatrix mat) {
	NumericMatrix m = mat;
	CharacterVector rows = rownames(m);
	for (int i = 0; i < rows.length(); i++) {
		// Iterate over rows
		for (int j = (i + 1); j < rows.length(); j++) {
			// Only iterate from i+1 onwards
			if (rows[i] == rows[j]) {
				// If a duplicate exists
				NumericMatrix::Row r1 = m( i , _ );
				NumericMatrix::Row r2 = m( j , _ );
				NumericVector v (m.cols());
				r1 = r1 + r2;
				r2 = v;
			} 
		}
	}
	return(m);
}

