#' VisualiseMarkers
#'
#' Function to visualize Seurat::FindMarkers() or Seurat::FindAllMarkers() output easily
#'
#' @param object A Seurat object to inspect idents in
#' @param name.1 Name of ident.1 to display
#' @param name.2 Name of ident.2 to display
#' @param order.by.fc Logical. Order results by FC or by p_val_adj
#' @param cluster Cluster of Seurat::FindAllMarkers output to visualise.
#' @return A heatmap plot of Find(All)Markers output displaying avg_log2FC, pct.1, pct.2, and p_val_adj
#' @export
#' @examples
#' VisualiseMarkers(FindMarkers(seuratobj, ident.1 = "CD4", ident.2 = "CD8"))
#' VisualiseMarkers(all_markers, name.1 = "Neurons", name.2 = "Rest", cluster = "Neurons")

VisualiseMarkers <- function(markers, name.1 = NULL, name.2 = NULL, order.by.fc = FALSE, cluster = NULL) {
  # Subset if cluster is specified, used w/ FindAllMarkers output
  if (!is.null(cluster)) {
    markers <- markers[markers$cluster==cluster,]
  }
  # Fix error when p_val_adj = 0
  markers$p_val_adj[markers$p_val_adj == 0] <- 1e-300

  # Create heatmap annotations
  Annotation <- ComplexHeatmap::rowAnnotation(
    name.1 = ComplexHeatmap::anno_barplot(markers$pct.1 * 100),
    name.2 = ComplexHeatmap::anno_barplot(markers$pct.2 * 100),
    "-log10(P adj)" = ComplexHeatmap::anno_points(-log(markers$p_val_adj,10)),
    width = unit(5,"cm"),
    gap = unit(0.15, "cm"),
    annotation_name_rot=90)
  
  # Specify ident names
  if (is.null(name.1)){
    name.1 <- "ident.1"
  }
  if (is.null(name.2)){
    name.2 <- "ident.2"
  }
  Annotation@anno_list$name.1@name <- paste("Expr%\n",name.1)
  Annotation@anno_list$name.1@label <- paste("Expr%\n",name.1)
  Annotation@anno_list$name.2@name <- paste("Expr%\n",name.2)
  Annotation@anno_list$name.2@label <- paste("Expr%\n",name.2)
  
  # Heatmap color scaling w/ white = 0
  colmin <- min(markers$avg_log2FC)
  colmax <- max(markers$avg_log2FC)
  if (colmax < 0){
    colmax <- colmin * -1
  } else if (colmin > 0) {
    colmin <- colmax * -1
  }
  colors <- circlize::colorRamp2(c(colmin, 0, colmax), c("blue","white","red"))
  
  # Return heatmap
  return(ComplexHeatmap::Heatmap(
    markers$avg_log2FC,
    name = "log2(FC)",
    col = colors,
    cluster_rows = order.by.fc,
    row_labels = rownames(markers),
    right_annotation = Annotation,
    width = unit(1,"cm"),
    column_title_rot=90))
}