#' FindSubCluster
#'
#' Wrapper for Seurat::FindSubCluster. Returns Seurat with subclusters in Idents(object) instead of a meta.data columns
#'
#' @param object A Seurat object to find subclusters in
#' @param cluster The cluster to be sub-clustered
#' @param graph.name The name of the graph to use for the clustering algorithm. Defaults to RNA_snn for convenience 
#' @param resolution Value of the resolution parameter, use a value above (below) 1.0 if you want to obtain a larger (smaller) number of communities.
#' @param algorithm Algorithm for modularity optimization (1 = original Louvain algorithm; 2 = Louvain algorithm with multilevel refinement; 3 = SLM algorithm; 4 = Leiden algorithm). Leiden requires the leidenalg python.
#' @return A Seurat object with subclusters stored in Idents(object) instead of a meta.data columns
#' @export
#' @examples
#' FindSubCluster(seuratobj, 'CD8+')
#' FindMarkers(FindSubCluster(seuratobj, "CD4+"), ident.1 = "CD4+_0", ident.2 = "CD4+_1")

FindSubCluster <- function(object, cluster, graph.name = 'RNA_snn', resolution = 0.5, algorithm = 1) {
  Idents(object) <- Seurat::FindSubCluster(object, cluster, graph.name, 'subcluster', resolution, algorithm)$subcluster
  return(object)
}