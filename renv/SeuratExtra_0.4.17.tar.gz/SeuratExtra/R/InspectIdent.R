#' InspectIdent
#'
#' Function to inspect a cluster based on the expressed markers
#'
#' @param object A Seurat object to inspect idents in
#' @param ident The cluster to be inspected
#' @param n.markers The n markers to base the inspection on
#' @param group.by Metadata column to find specified ident in. Defaults to Idents(object)
#' @param ... Function argument to be passed to Seurat::FindMarkers()
#' @param all.markers Data.frame output of Seurat::FindAllMarkers() to extract markers instead of computing internally.
#' @return A patchwork plot with UMAPs and marker cluster enrichment in Zeisel et al. (2018) [Ref]
#' @export
#' @examples
#' InspectIdent(seuratobj, 0, all.markers = all_markers)
#' InspectIdent(seuratobj, "CD8+", n.markers=6, test.use="MAST")

InspectIdent <- function(object, ident, n.markers = 5, group.by="ident", ..., all.markers = NULL){
  if (length(n.markers) == 1) {
    n.markers <- 1:n.markers
  }
  if (group.by != "ident") {
    Idents(object) <- object[[group.by]] %>% purrr::pluck(1)
  }
  if (is.null(all.markers)) {
    #Calc markers & get top n.markers
    Markers <- FindMarkers(object, ident.1=ident, ...)
    Genes <- row.names(Markers[Markers$avg_log2FC > 0,])[n.markers]
  } else {
    #Markers already calculated & get top n markers
    Markers <- all.markers
    Genes <- Markers$gene[Markers$avg_log2FC > 0 & Markers$cluster == ident][n.markers]
  }
  #Scale for heatmap
  Scaled <- ScaleData(object, Genes, verbose=F)
  
  #Bar plot of cluster marker enrichment
  p0 <- list()
  IdentToDesc <- unique(ClassesNeuralLinnarsson[[c("ClusterName","Description")]])
  for (Gene in Genes) {
    if (Gene %in% row.names(ClassesNeuralLinnarsson)) {
      AverageExpression(ClassesNeuralLinnarsson,"RNA",Gene)$RNA %>% t() %>% 
        as.data.frame() %>%
        mutate(Cluster = row.names(.)) %>%
        mutate(Description = RExtra::mapvalues(Cluster, IdentToDesc$ClusterName, IdentToDesc$Description)) %>%
        rename("Expression" = "V1") %>%
        arrange(desc(Expression)) %>%
        head(5) %>%
        ggplot()+
        geom_bar(aes(x=reorder(Cluster, Expression), y=Expression, fill=Cluster), stat = 'identity')+
        geom_text(aes(x=reorder(Cluster, Expression), y=min(Expression/15), label=Description), hjust=0)+
        ggtitle(Gene)+
        coord_flip()+
        theme_classic()+
        theme(axis.title = element_blank(), 
              title = element_text(face = "bold", size=12, hjust=0.5),
              legend.position = "none") -> p0[[(length(p0) + 1)]]
    } else {
      p0[[(length(p0) + 1)]] <- ggplot()+
        ggtitle(Gene)+
        scale_x_continuous(limits = c(0,10))+
        theme_classic()+
        theme(title = element_text(face = "bold", size=12, hjust=0.5))
    }
    
  }
  p0 <- patchwork::wrap_plots(p0, ncol=1)
  
  #Plot
  p <- patchwork::wrap_plots(
    FeaturePlot(Scaled, Genes, ncol=1)&
      theme_classic()&
      theme(legend.position = "none", axis.title = element_blank(),
            title = element_text(face = "bold", size=12, hjust=0.5)),
    FeaturePlot(object[,Idents(object)==ident], Genes, ncol=1)&
      theme_classic()&
      theme(legend.position = "none", axis.title = element_blank(),
            title = element_text(face = "bold", size=12, hjust=0.5)),
    p0,
    ncol=3)
  return(p)
}