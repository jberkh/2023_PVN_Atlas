#' GetReduction
#'
#' Extract the reduction from a Seurat object
#'
#' @param object A Seurat object from which to extract the reduction 
#' @param reduction The name of the reduction to extract
#' @param dims The dimension(s) of the reduction to extract. Defaults to the first two
#' @return A matrix w/ reduction coordinates of the specified dims, per cell.
#' @export
#' @examples
#' GetReduction(seuratobj, "umap", 1)
#' GetReduction(seuratobj, "pca", 1:2)

#Easier reduction coordinates
GetReduction <- function(object, reduction="umap", dims = 1:2){
  if (class(object)!='Seurat'){
    print(deparse(substitute(object)) %&% 'is not a Seurat object.')
  } else {
    if (max(dims) > dim(object@reductions[[reduction]]@cell.embeddings)[2] | min(dims) < 1){
      print('Requested dimension(s) exceed(s) reductions dimension limits')
    } else{
      return(object@reductions[[reduction]]@cell.embeddings[,dims])
    }
  }
}