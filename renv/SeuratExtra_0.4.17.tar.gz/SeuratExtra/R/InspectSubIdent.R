#' InspectSubIdent
#'
#' Function to easily inspect subclusters in their parent cluster context
#'
#' @param object A Seurat object to inspect idents in
#' @param subident The subcluster to be inspected. Must contain "_[0-9]" subcluster notation
#' @param n.markers The n markers to base the inspection on
#' @param group.by Metadata column to find specified ident in. Defaults to Idents(object)
#' @param ... Function argument to be passed to Seurat::FindMarkers()
#' @return A patchwork plot with violin plots and UMAPs of cluster markers
#' @export
#' @examples
#' InspectSubIdent(seuratobj, "Neurons_0")
#' InspectSubIdent(FindSubCluster(Seurat, "CD8"), "CD8_0", n.markers=6, test.use="MAST")

InspectSubIdent <- function(object, subident, n.markers = 5, group.by = "ident", ...){
  if (group.by != "ident") {
    Idents(object) <- object[[group.by]] %>% purrr::pluck(1)
  }
  #Get parent.ident
  parent.ident <- strsplit(subident,"_")[[1]]
  parent.ident[length(parent.ident)] <- ""
  parent.ident <- paste0(parent.ident, collapse="_")
  #Subselect only parent ident & calc markers
  object <- object[,grep(parent.ident, Idents(object))]
  Markers <- FindMarkers(object, ident.1=subident, verbose=F, ...)
  #Top n markers & scale for heatmap
  Genes <- row.names(head(Markers[Markers$avg_log2FC > 0,], n.markers))
  Scaled <- ScaleData(object, Genes, verbose=F)
  Idents(Scaled) <- factor(paste0("_", str_remove(Idents(Scaled),"^.*_")),
                           levels = unique(paste0("_", sort(str_remove(Idents(Scaled),"^.*_")))))
  #Plot
  p <- patchwork::wrap_plots(
    VlnPlot(Scaled, Genes, ncol=1)&
      theme_classic()&
      theme(legend.position = "none", axis.title = element_blank(),
            title = element_text(face = "bold", size=12, hjust=0.5)),
    FeaturePlot(Scaled, Genes, ncol=1)&
      theme_classic()&
      theme(legend.position = "none", axis.title = element_blank(),
            title = element_text(face = "bold", size=12, hjust=0.5)),
    FeaturePlot(object[,Idents(object)==subident], Genes, ncol=1)&
      theme_classic()&
      theme(legend.position = "none", axis.title = element_blank(),
            title = element_text(face = "bold", size=12, hjust=0.5)),
    ncol=3)
  plot(p)
}