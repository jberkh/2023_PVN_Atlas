#' MergeRowsByGeneNames
#'
#' Merge rows with same gene names
#'
#' @param expr.mat A matrix with gene names on the rows
#' @return A matrix with rows merged by gene name
#' @importFrom Matrix Matrix
#' @export
#' @examples
#' MergeRowsByGeneNames(expr.mat)


MergeRowsByGeneNames <- function(expr.mat) {
  if (is.null(row.names(expr.mat))) {
    warning("Rows must be named!")
    return()
  }
  expr.mat = Matrix(rcpp_merge_by_row(as.matrix(expr.mat)))
  expr.mat = expr.mat[!duplicated(row.names(expr.mat)),]
  return(expr.mat)
}
