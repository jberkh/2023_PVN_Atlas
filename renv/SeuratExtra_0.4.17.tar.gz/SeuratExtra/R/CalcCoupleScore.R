#' CalcCoupleScore
#'
#' Function to calculate coupling score of two sets of features per cell type, as used by Viho et al. (2021) [Ref]
#'
#' @param object A Seurat object to inspect idents in
#' @param assay The Seurat assay to use to calculate the coupling score 
#' @param group.by Metadata column to group cell types by. Defaults to Idents(object)
#' @param features.1 Feature set 1 
#' @param features.2 Feature set 2
#' @return A list of coupling matrices (features.2 x cell types) per feature.1 component
#' @export
#' @examples
#' CalcCoupleScore(seuratobj, "RNA", features.1 = "Nr3c1", features.2 = c("Ncoa1","Ncoa2"))

# Function to calculate coupling score of two sets of features per cell type
CalcCoupleScore <- function(object, assay, group.by = "ident", features.1 = NULL, features.2 = NULL) {
  CouplingScores <- list()
  for (feature.1 in features.1) {
    coupscore <- NULL
    for (feature.2 in features.2) {
      x_i <- AverageExpression(object, assay, feature.1, group.by = group.by)[[1]]
      x_j <- AverageExpression(object, assay, feature.2, group.by = group.by)[[1]]
      x_ij <- x_i * x_j
      x_ij[x_ij == 0] <- NA
      coupscore <- rbind(coupscore, x_ij)
      row.names(coupscore)[nrow(coupscore)] <- feature.2
    }
    coupscore <- log(coupscore, 10)
    coupscore <- (coupscore - min(coupscore, na.rm = T))
    coupscore <- coupscore / (max(coupscore, na.rm = T) - min(coupscore, na.rm = T))
    CouplingScores[[feature.1]] <- coupscore
  }
  return(CouplingScores)
}