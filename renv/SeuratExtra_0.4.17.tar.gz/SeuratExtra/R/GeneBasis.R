#' GeneBasis
#'
#' Wrapper for geneBasisR::gene_search to be used with Seurat.
#'
#' @param object A Seurat object
#' @param genes_base Character vector specifying base genes to construct first Selection graph. Default=NULL in case no genes are supplied.
#' @param n_genes_total Scalar specifying total number of genes to be selected (this includes base genes).
#' @param batch Name of the field in metadata to specify batch. Default batch=NULL if no batch is applied.
#' @param n.neigh Positive integer > 1, specifying number of neighbors to use for kNN-graph. Default n.neigh=5.
#' @param p.minkowski Order of Minkowski distance. Default p.minkowski=3.
#' @param nPC.selection Scalar specifying number of PCs to use for Selection Graphs. Default nPC=NULL.
#' @param nPC.all Scalar specifying number of PCs to use for True Graph. Default nPC.all=50.
#' @param genes.discard Character vector containing genes to be excluded from candidates (note that they still will be used for graphs construction. If you want to exclude them from graph construction as well, just discard them prior in sce object). Default = NULL and no genes will be discarded.
#' @param genes.discard_prefix Character vector containing prefixes of genes to be excluded (e.g. Rpl for L ribosomal proteins. Note that they still will be used for graphs construction. If you want to exclude them from graph construction as well, just discard them prior in sce object). Default = NULL and no genes will be discarded.
#' @param verbose Boolean identifying whether intermediate print outputs should be returned. Default verbose=TRUE.
#' @return Seurat object with the GeneBasis gene selection in the VariableFeatures slot
#' @export
#' @examples
#' GeneBasis(seuratobj, n_genes_total=100) |> ScaleData() |> RunPCA()
#' 

GeneBasis <- function(object, genes_base = NULL, n_genes_total, batch = NULL, n.neigh = 5, p.minkowski = 3, 
                      nPC.selection = NULL, nPC.all = 50, genes.discard = NULL, genes.discard_prefix = NULL, verbose = TRUE) {
    sce <- Seurat::as.SingleCellExperiment(object)
    sce <- geneBasisR::retain_informative_genes(sce)
    genes <- geneBasisR::gene_search(sce, genes_base, n_genes_total, batch, n.neigh, p.minkowski, 
                                     nPC.selection, nPC.all, genes.discard, genes.discard_prefix, verbose)
    Seurat::VariableFeatures(object) <- genes$gene
    return(object)
}