#' StandardiseGeneNames
#'
#' Standardise gene names of a expression matrix
#'
#' @param genes A character vector containing gene names
#' @param organism Currently, only mus musculus is supported
#' @param return.df Logical. Return data.frame with input, intermediate and output gene names
#' @return A character vector containing mgi symbols as far as input is convertible
#' @importFrom RExtra mapvalues %!in% +
#' @export
#' @examples
#' StandardiseGeneNames(genelist)

StandardiseGeneNames <- function(genes, organism = c("mmu"), force.unique = FALSE, return.df = FALSE) {
  tmp <- data.frame(X = genes)
  # First pass only unique conversions
  tmp$p1 <- mapvalues(tmp$X, mgi$uniq$Synonym, mgi$uniq$Symbol)
  # Ignore genes converted from valid mgi symbols
  tmp$p1[tmp$X %in% mgi$all_symb] <- 
    tmp$X[tmp$X %in% mgi$all_symb]
  
  if (force.unique) {
    # Ignore genes converted to existing symbols
    tmp$p1[tmp$p1 %in% tmp$X] <- tmp$X[tmp$p1 %in% tmp$X]
  }
  
  pct_p1 <- as.integer(sum(tmp$X != tmp$p1)/nrow(tmp) * 100)
  print("First pass completed! Percentages of genes changed: " + pct_p1 + "%") 
  print("Starting second pass...")
  
  # Second pass iterate over first pass results
  tmp$p2 <- rcpp_pass_two(tmp$p1, mgi$dupl$Synonym, mgi$dupl$Symbol, mgi$all_symb)
  pct_p2 <- as.integer(sum(tmp$p1 != tmp$p2)/nrow(tmp) * 100)
  print("Second pass complete! Percentages of genes changed: " + pct_p2 + "%")
  if (return.df) return(tmp)
  return(tmp$p2)
}

