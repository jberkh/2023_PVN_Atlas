#' InspectIdent
#'
#' Function to inspect a cluster based on the expressed markers
#'
#' @param object A Seurat object to inspect idents in
#' @param ident The cluster to be inspected
#' @param ... Function arguments to be passed to Seurat::DimPlot()
#' @return A patchwork plot with all cells of identify 'ident'
#' @export
#' @examples
#' InspectIdent(seuratobj, 0, all.markers = all_markers)
#' InspectIdent(seuratobj, "CD8+", n.markers=6, test.use="MAST")

LocateIdent <- function(object, ident, ...) {
    p <- Seurat::DimPlot(object, cells.highlight = Seurat::WhichCells(object, idents = ident), ...)
    return(p)
}